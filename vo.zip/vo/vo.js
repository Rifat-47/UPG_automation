const { makeVoQueries, saveToFile, getVoDetailsList } = require("./vo.utils");

/* Add VO query generator info */

const branches = [
  {
    branch_name: "Birol",
    branch_code: "0238",
    po_name: "Mst. Aiirin Nahar",
    po_pin: "266877",
  },
  {
    branch_name: "Khansama",
    branch_code: "1336",
    po_name: "Bankim madhu",
    po_pin: "252685",
  },
  {
    branch_name: "Dinajpur Sadar",
    branch_code: "0556",
    po_name: "Anusha Holla",
    po_pin: "203407",
  },
  {
    branch_name: "Chirir Bondar",
    branch_code: "0252",
    po_name: "Reema Chavare",
    po_pin: "261564",
  },
  {
    branch_name: "Fulbari",
    branch_code: "0528",
    po_name: "Prathiksha Bhardwaj",
    po_pin: "624761",
  },
  {
    branch_name: "Shyamnagar",
    branch_code: "1488",
    po_name: "Bhoomika Vernekar",
    po_pin: "769679",
  },
  {
    branch_name: "Satkhira Sadar",
    branch_code: "0450",
    po_name: "Pavati Rao",
    po_pin: "482182",
  },
  {
    branch_name: "Debhata",
    branch_code: "0208",
    po_name: "Shravya Anchan",
    po_pin: "542535",
  },
  {
    branch_name: "Fultala",
    branch_code: "0223",
    po_name: "Murad Hossain",
    po_pin: "172527",
  },
  {
    branch_name: "Batiaghata",
    branch_code: "0379",
    po_name: "Apu Sarkar",
    po_pin: "265977",
  },
  {
    branch_name: "Dumuria",
    branch_code: "0222",
    po_name: "Ratna Mondal",
    po_pin: "142497",
  },
  {
    branch_name: "Dacope",
    branch_code: "1493",
    po_name: "Shamsunnahar",
    po_pin: "266797",
  },
];

const groupName = "UPG Group-02";

let randomVONo = 1942321;
const totalVO = 4; // How many VO you want to create
const voNames = ["Ashim", "Rifat", "Moinul", "Shakil"];

const memberInVO = 10; // How many participants in one VO
const voMemberNames = [
  "Asma Akhter",
  "Sheuli Begum",
  "Kulsum Begum",
  "Shilpi Akhter",
  "Jothi Akhter",
  "Md. Gias Uddin",
  "Gias",
  "Uddin",
  "Jothi",
  "Begum",
];

/* /Add VO query generator info */

/* execute */

const { queries, vos } = makeVoQueries(
  branches,
  randomVONo,
  totalVO,
  voNames,
  memberInVO,
  voMemberNames,
  groupName
);

const voQueryFileName = "vo-queries.txt";
saveToFile(voQueryFileName, queries);
console.log(`Plz!!! check your file = "${voQueryFileName}" to get vo queries.`);

const voDetailsList = getVoDetailsList(vos);

const voDetailsFileName = "vo-details.txt";
saveToFile(voDetailsFileName, voDetailsList);
console.log(
  `Plz!!! check your file = "${voDetailsFileName}" to get vo details.`
);

/* /execute */
