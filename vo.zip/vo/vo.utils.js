const fs = require("fs");

function getVoQuery(branch, voId, voName, date, groupName) {
  return `INSERT INTO erp_vo ("branch_code", "org_no", "branch_id", "collection_date", "created", "created_by", "group_name", "group_status_id", "is_active", "next_collection_date", "po_name", "po_pin", "updated", "updated_at", "updated_by", "vo_id", "vo_name") VALUES ('${branch.branch_code}', '${voId}', '${branch.branch_code}', '${date} 00:00:00.000+0000', '${date} 00:00:00', NULL, '${groupName}', '1', true, NULL, '${branch.po_name}', '${branch.po_pin}', NULL, '${date} 00:00:00', NULL, '${voId}', '${voName}');`;
}

function getVoMemberQuery(
  branch,
  voId,
  voName,
  memberId,
  voMemberName,
  date,
  groupName
) {
  return `INSERT INTO erp_vo_member ("vo_id", "member_id", "application_date", "branch_code", "branch_id", "created", "created_by", "group_name", "is_active", "member_enterprise", "member_name", "member_status_id", "org_mem_no", "org_no", "po_name", "po_pin", "updated", "updated_at", "updated_by", "vo_name") VALUES ('${voId}', '${memberId}', '${date}', '${branch.branch_code}', '${branch.branch_code}', '${date} 00:00:00.000+0000', NULL, '${groupName}', true, NULL, '${voMemberName}', 1, '2', '${voId}', '${branch.po_name}', '${branch.po_pin}', '${date} 00:00:00.000+0000', '${date} 00:00:00', NULL, '${voName}');`;
}

function makeVoQueries(
  branches,
  voId,
  totalVO,
  voNames,
  memberInVO,
  voMemberNames,
  groupName
) {
  const queries = [];
  const vos = {};
  const date = new Date().toISOString().substring(0, 10);

  for (let i = 0; i < branches.length; i++) {
    const branch = branches[i];

    for (let j = 0; j < totalVO; j++) {
      const voQuery = getVoQuery(branch, voId, voNames[j], date, groupName);
      queries.push(voQuery);

      vos[branch.branch_name] = { ...vos[branch.branch_name], [voId]: [] };

      for (let k = 0; k < memberInVO; k++) {
        const memberId = `${voId}${voId}${k}`;
        const voMemberQuery = getVoMemberQuery(
          branch,
          voId,
          voNames[j],
          memberId,
          voMemberNames[k],
          date,
          groupName
        );
        queries.push(voMemberQuery);

        vos[branch.branch_name][voId].push(memberId);
      }

      voId++;
    }
  }

  return { queries, vos };
}

function printQueries(queries) {
  queries.forEach((query) => console.log(query));
}

/** Save string array to a file
 * @param fileName: string
 * @param list: string array
 */
function saveToFile(fileName, list) {
  fs.writeFileSync(fileName, list.join("\n"));
}

function printVos(vos) {
  for (const [branchName, vosByBranch] of Object.entries(vos)) {
    for (const [voId, voMembers] of Object.entries(vosByBranch)) {
      console.log(
        `branch_name: ${branchName}, vo_id: ${voId}, vo_members: ${voMembers.join(
          ", "
        )}`
      );
    }
  }
}

function getVoDetailsList(vos) {
  const voDetailsList = [];

  for (const [branchName, vosByBranch] of Object.entries(vos)) {
    const vos = Object.keys(vosByBranch);
    const voDetails = `branch_name: ${branchName}, vo_ids: ${vos.join(", ")}`;
    voDetailsList.push(voDetails);
    // for (const [voId, voMembers] of Object.entries(vosByBranch)) {
    //   const voDetails = `branch_name: ${branchName}, vo_id: ${voId}, vo_members: ${voMembers.join(
    //     ", "
    //   )}`;
    //   voDetailsList.push(voDetails);
    // }
  }

  return voDetailsList;
}

module.exports.makeVoQueries = makeVoQueries;
module.exports.printQueries = printQueries;
module.exports.saveToFile = saveToFile;
module.exports.printVos = printVos;
module.exports.getVoDetailsList = getVoDetailsList;
